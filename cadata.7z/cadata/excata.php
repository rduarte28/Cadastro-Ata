<?php
    include 'conecta.php';
    
    $idata = $_GET['idata'];
    $sql = "DELETE FROM ata WHERE idata=$idata";
    if (mysqli_query($mysqli, $sql)) {
        echo "<script language='javascript' type='text/javascript'>
            window.location.href='atacadastrada.php';
            </script>";
    }
    mysqli_close($mysqli);
?>