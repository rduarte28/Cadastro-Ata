<?php
    include 'conecta.php';
    $nome = $_POST['nome'];
    $empresa = $_POST['empresa'];
    $email = $_POST['email'];
  
   
    $query = $mysqli->query("SELECT * FROM participanteexterno WHERE nome='$nome' AND empresa='$empresa' OR email='$email'");
    if (mysqli_num_rows($query) > 0) {
        echo "<script language='javascript' type='text/javascript'>
        alert('Participante Externo já existe em nossa base de dados!');
        window.location.href='partext.php';
        </script>";
        exit();
    }
    else {
        $sql = "INSERT INTO participanteexterno(nome,empresa,email) VALUES ('$nome','$empresa','$email')";
        if (mysqli_query($mysqli, $sql)) {
            echo "<script language='javascript' type='text/javascript'>
            alert('Participante Externo Cadastrado com Sucesso!');
            window.location.href='partext.php';
            </script>";
        }
    }
    mysqli_close($mysqli);
?>