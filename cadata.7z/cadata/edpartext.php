<?php
    include 'conecta.php';

    $idpartext = $_GET['idpartext'];
    $nome = $_POST['nome'];
    $empresa = $_POST['empresa'];
    $email = $_POST['email'];
    
    $sql = "UPDATE participanteexterno SET nome=?,empresa=?,email=? WHERE idpartext=?";
    $edu = $mysqli->prepare($sql) or die($mysqli->error);
    if (!$edu) {
        echo "Erro:".$mysqli->error;
    }
    $edu->bind_param('sssi',$nome,$empresa,$email,$idpartext);
    $edu->execute();
    $edu->close();
    header("Location: partext.php");
?>