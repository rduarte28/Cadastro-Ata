<?php
    include 'conecta.php';
    $idfuncionario = $_GET['idfuncionario'];
    $sql = "DELETE FROM funcionario WHERE idfuncionario=$idfuncionario";
    if (mysqli_query($mysqli, $sql)) {
        echo "<script language='javascript' type='text/javascript'>
            window.location.href='funcionario.php';
            </script>";
    }
    mysqli_close($mysqli);
?>