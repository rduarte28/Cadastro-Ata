<?php
    include 'conecta.php';

    $idfuncionario = $_GET['idfuncionario'];
    $nome = $_POST['nome'];
    $matricula = $_POST['matricula'];
    $sexo = $_POST['sexo'];
    $email = $_POST['email'];
    $datanascimento = $_POST['datanascimento'];
    $sql = "UPDATE funcionario SET nome=?,matricula=?,sexo=?,email=?,datanascimento=? WHERE idfuncionario=?";
    $edu = $mysqli->prepare($sql) or die($mysqli->error);
    if (!$edu) {
        echo "Erro:".$mysqli->error;
    }
    $edu->bind_param('sssssi',$nome,$matricula,$sexo,$email,$datanascimento,$idfuncionario);
    $edu->execute();
    $edu->close();
    header("Location: funcionario.php");
?>