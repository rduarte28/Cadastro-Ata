<?php
include 'conecta.php';
$idfuncionario = $idfuncionario;
$sql = "SELECT * FROM funcionario WHERE idfuncionario=$idfuncionario";
$query = $mysqli->query($sql);
while ($dados = $query->fetch_array()) {
    $nome = $dados['nome'];
    $matricula = $dados['matricula'];
    $sexo = $dados['sexo'];
    $email = $dados['email'];
    $datanascimento = $dados['datanascimento'];
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <form action="edfuncionario.php?id=<?php echo $idfuncionario; ?>" method="post">
        <label class="form-label">Nome</label>
        <input class="form-control" type="text" name="nome" required value="<?php echo $nome; ?>" />
        <br />
        <label class="form-label">Matrícula</label>
        <input class="form-control" type="number" name="matricula" required value="<?php echo $matricula; ?>" />
        <br />
        <label class="form-label">Sexo</label>
        <select class="form-select" name="sexo">
            <option selected><?php echo $sexo; ?></option>
            <option value="Masculino">Masculino</option>
            <option value="Feminino">Feminino</option>
        </select>
        <br />
        <label class="form-label">E-mail</label>
        <input class="form-control" type="email" name="email" required value="<?php echo $email; ?>" />
        <br />
        <label class="form-label">Data de Nascimento</label>
        <input class="w3-input w3-border" value="<?php echo date('Y-m-d'); echo $datanascimento; ?>" type="date"  name="datanascimento" required>
        <br />
        <input type="submit" class="btn btn-outline-success" value="ATUALIZAR" />
    </form>
</body>

</html>