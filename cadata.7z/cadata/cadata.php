
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-language" content="pt-br">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CADASTRO DE ATAS - TDS04</title>
    <style>
        .header {
            float: right;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <h2><b>CADASTRO DE ATAS - TDS04</b></h2>
       <br />
    <hr />
    <nav>
        <?php
        include 'menu.php';
        ?>
    </nav>
    <br />
    <br />
    <div class="row justify-content-center row-cols-1 row-cols-md-2 mb-2 text-center">
        <div class="col">
            <div class="card mb-2 rounded-3 shadow-sw">
                <div class="card-header py-3">
                    <h3 class="my-0 fw-normal"><svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="#6A5ACD" class="bi bi-people-fill" viewBox="0 0 16 16">
                            <path d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6m-5.784 6A2.24 2.24 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.3 6.3 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1zM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5" />
                        </svg>&nbsp;&nbsp;<b>Registro de ATA</b></h3>
                    <button type="button" class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#exampleModal">Registrar ATA</button>
                </div>
                
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Registro de Ata</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="cadastroata.php" method="post">
                
                        <label class="form-label">Título</label>
                        <input class="form-control" type="text" name="titulo" required placeholder="Digite o Título da Ata"/>
                        <br/>
                        <label class="form-label">Data de Emissão</label>
                        <input class="w3-input w3-border" value="<?php echo date('Y-m-d');?>" type="date"  name="dataemissao" required>
                        <br/>
                        <label class="form-label">Data de Início</label>
                        <input class="w3-input w3-border" value="<?php echo date('Y-m-d');?>" type="date"  name="inicio" required>
                        <br/>
                        <label class="form-label">Data Término</label>
                        <input class="w3-input w3-border" value="<?php echo date('Y-m-d');?>" type="date"  name="termino" required>
                        <br/>
                        <label class="form-label">Setor</label>
                        <input class="form-control" type="text" name="setor" required placeholder="Digite o Setor"/>
                        <br/>
                        <label class="form-label">Pauta</label>
                        <input class="form-control" type="text" name="pauta" required placeholder="Digite a Pauta da Ata"/>
                        <br/>
                        <label class="form-label">Descrição</label>
                        <input class="form-control" type="text" name="descricao" required placeholder="Digite a Descrição da Ata"/>
                        <br/>
                        <label class="form-label">Palavra Chave</label>
                        <input class="form-control" type="text" name="palavrachave" required placeholder="Digite palavras chave para esta Ata"/>
                        <br/>
                        <label class="form-label">Tipo</label>
                        <input class="form-control" type="text" name="tipo" required placeholder="Digite o Tipo"/>
                        <br/>
                        <label class="form-label">Status</label>
                        <select class="form-select" aria-label="Selecione um status" name="atastatus">
                            <option selected>Selecione o Status da Ata </option>
                            <option value="Concluida">Concluida</option>
                            <option value="Reagendada">Reagendada</option>
                            
                        </select>
                        <br/>
                        <br/>
                        <br/>
                        <br/>
                        
                        <input type="submit" class="btn btn-outline-success" value="CADASTRAR"/>
                        
                    </form>
                </div>
                
</html>