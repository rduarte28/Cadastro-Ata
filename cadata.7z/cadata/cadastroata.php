<?php
    include 'conecta.php';
    $titulo = $_POST['titulo'];
    $dataemissao = $_POST['dataemissao'];
    $inicio = $_POST['inicio'];
    $termino = $_POST['termino'];
    $setor = $_POST['setor'];
    $pauta = $_POST['pauta'];
    $descricao = $_POST['descricao'];
    $palavrachave = $_POST['palavrachave'];
    $tipo = $_POST['tipo'];
    $atastatus = $_POST['atastatus'];
   
    $query = $mysqli->query("SELECT * FROM ata WHERE titulo='$titulo' AND pauta='$pauta' OR atastatus='$atastatus'");
    if (mysqli_num_rows($query) > 0) {
        echo "<script language='javascript' type='text/javascript'>
        alert('Ata já existe em nossa base de dados!');
        window.location.href='atacadastrada.php';
        </script>";
        exit();
    }
    else {
        $sql = "INSERT INTO ata (titulo,dataemissao,inicio,termino,setor,pauta,descricao,palavrachave,tipo,atastatus) VALUES ('$titulo','$dataemissao','$inicio','$termino','$setor','$pauta','$descricao','$palavrachave','$tipo','$atastatus')";
        if (mysqli_query($mysqli, $sql)) {
            echo "<script language='javascript' type='text/javascript'>
            window.location.href='atacadastrada.php';
            </script>";
        }
    }
    
    mysqli_close($mysqli);
?>