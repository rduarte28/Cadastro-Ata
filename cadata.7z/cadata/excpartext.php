<?php
    include 'conecta.php';
    $idpartext = $_GET['idpartext '];
    $sql = "DELETE FROM participanteexterno WHERE idpartext=$idpartext";
    if (mysqli_query($mysqli, $sql)) {
        echo "<script language='javascript' type='text/javascript'>
            window.location.href='partext.php';
            </script>";
    }
    mysqli_close($mysqli);
?>