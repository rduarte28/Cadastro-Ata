<?php
include 'conecta.php';
$idpartext = $idpartext;
$sql = "SELECT * FROM participanteexterno WHERE idpartext=$idpartext";
$query = $mysqli->query($sql);
while ($dados = $query->fetch_array()) {
    $nome = $dados['nome'];
    $empresa = $dados['empresa'];
    $email = $dados['email'];
    
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <form action="edpartext.php?id=<?php echo $idpartext; ?>" method="post">
        <label class="form-label">Nome</label>
        <input class="form-control" type="text" name="nome" required value="<?php echo $nome; ?>" />
        <br />
        <label class="form-label">Empresa</label>
        <input class="form-control" type="text" name="empresa" required value="<?php echo $empresa; ?>" />
        <br />
        <label class="form-label">E-mail</label>
        <input class="form-control" type="email" name="email" required value="<?php echo $email; ?>" />
        <br />
        <input type="submit" class="btn btn-outline-success" value="ATUALIZAR" />
    </form>
</body>

</html>