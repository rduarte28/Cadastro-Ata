<?php
    include 'conecta.php';
    $nome = $_POST['nome'];
    $matricula = $_POST['matricula'];
    $sexo = $_POST['sexo'];
    $email = $_POST['email'];
    $datanascimento = $_POST['datanascimento'];
   
    $query = $mysqli->query("SELECT * FROM funcionario WHERE nome='$nome' AND matricula='$matricula' OR matricula='$matricula'");
    if (mysqli_num_rows($query) > 0) {
        echo "<script language='javascript' type='text/javascript'>
        alert('Usuário já existe em nossa base de dados!');
        window.location.href='funcionario.php';
        </script>";
        exit();
    }
    else {
        $sql = "INSERT INTO funcionario(nome,matricula,sexo,email,datanascimento) VALUES ('$nome','$matricula','$sexo','$email','$datanascimento')";
        if (mysqli_query($mysqli, $sql)) {
            echo "<script language='javascript' type='text/javascript'>
            alert('Usuário Cadastrado com Sucesso!');
            window.location.href='funcionario.php';
            </script>";
        }
    }
    mysqli_close($mysqli);
?>