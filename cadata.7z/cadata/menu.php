<?php
    
    include 'conecta.php';
   
    
        echo "<a href='cadata.php' style='color: black; text-decoration: none'>HOME</a>";
        echo "<b> | </b>";
        echo "<a href='atacadastrada.php' style='color: black; text-decoration: none'>Atas Cadastradas</a>";
        echo "<b> | </b>";
        echo "<a href='funcionario.php' style='color: black; text-decoration: none'>Funcionários</a>";
        echo "<b> | </b>";
        echo "<a href='partext.php' style='color: black; text-decoration: none'>Participantes Externos</a>";
        echo "<b> | </b>";
        echo "<a href='sugestoes.php' style='color: black; text-decoration: none'>Sugestões</a>";
        echo "<b> | </b>";
        
   
        
     
?>